import CardView from './Card'

const PetList = () => {
  return (
   <div className="list-pet">
        <CardView />
    </div>
  )
}

export default PetList

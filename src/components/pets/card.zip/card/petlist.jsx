import CardView from './CardView';

const PetList = () => {
  return (
    <div className="pet-list">
      <CardView />
    </div>
  );
};

export default PetList;

// import Footer from "../../Siteframe/Footer"
import Header from "../../Siteframe/Header"
import CardView from "./PetInfo"

const Info = () => {
  return (
    <>
     <Header />
      <CardView />
    {/* <Footer/> */}
    </>
   
  )
}

export default Info
